package com.example.mvppracticeproject.Home;

public interface IHome {
}
