package com.example.mvppracticeproject.Home;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.mvppracticeproject.R;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }
}
